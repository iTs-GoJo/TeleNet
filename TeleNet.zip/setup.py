from setuptools import setup, find_packages
setup(
    name="telenet",
    version="0.2.0",
    packages=find_packages(),
    install_requires=["aiohttp>=3.9"],
)