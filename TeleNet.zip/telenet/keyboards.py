class InlineButton:
    def __init__(self, text, callback_data=None):
        self.text = text
        self.callback_data = callback_data

class InlineKeyboard:
    def __init__(self): self.rows = []
    def row(self, *buttons): self.rows.append(list(buttons)); return self
    def to_markup(self):
        return {"inline_keyboard": [[{"text": b.text, "callback_data": b.callback_data} for b in row] for row in self.rows]}